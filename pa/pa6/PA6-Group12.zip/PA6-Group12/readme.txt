20120239 - Thái Mai Khánh Vy - Chức năng đăng nhập/đăng xuất: https://youtu.be/yeGsOtXUxdQ
20120270 - Cao Tấn Đức -  Chức năng xem thông tin cá nhân, thời khóa biểu và Danh sách lớp mở:https://youtu.be/wNEBSGDgZwg
20120274 - Nguyễn Linh Đăng Dương - Chức năng đăng ký học phần/ hủy đăng ký học phần: https://www.youtube.com/watch?v=NP9hVZqKgWc
20120284 - Lê Đức Hậu - Chức năng xem kết quả đăng ký học phần và Lịch sử đăng ký học phần: https://www.youtube.com/watch?v=XCkW9TIf8RI
20120288 - Nguyễn Trung Hiếu - Chức năng tạo/huỷ yêu cầu trao đổi, trao đổi học phần: https://youtu.be/PKBu3Hs9ukk

All automated testing project: 

Presentation: https://docs.google.com/presentation/d/165k-Z-2-qMPCXOz8eacECaxEomXulzfc/edit?usp=share_link&ouid=113206634985992757004&rtpof=true&sd=true